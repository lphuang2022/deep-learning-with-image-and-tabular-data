from utils_cat21 import *
import numpy as np
import pandas as pd
from scipy import interpolate as interpolate
import mpu

def match_to_runway(lat, lon):
    rwyLabels = []
    if len(lon) != len(lat):
        print("interpolate wrong: No. of Lon != No. of Lat")
    for i in range(len(lat)):
        pointData = (lon[i], lat[i])
        rwy = ""       
        if Point(pointData).within(shape(shp1_data)):
            rwy = '02L20R'
        elif Point(pointData).within(shape(shp2_data)):
            rwy = "02C20C"
        elif Point(pointData).within(shape(shp3_data)):
            rwy = "02R20L"
        else:
            rwy = "other"
        rwyLabels.append(rwy)
    return rwyLabels

def get_runwayNanme(runwayLabels):
    runwayName = list(set(runwayLabels))
    if 'other' in runwayName:
        runwayName.remove('other')

    if len(runwayName)>1:
        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')

    return runwayName

def get_runwayTHR(coor, runway):
    if runway == 'other':
        return runway
    thr1 = runway[0:3]
    thr2 = runway[3:]
    coor_thr1 = runwayTHRs[thr1]
    coor_thr2 = runwayTHRs[thr2]
    dist1 = mpu.haversine_distance(coor, coor_thr1)*1000
    dist2 = mpu.haversine_distance(coor, coor_thr2)*1000

    return thr1 if dist1<dist2 else thr2


def get_runwayTHR_timestamp_byAC(data_csign):
    lat, lon = data_csign['lat'].to_list(), data_csign['lon'].to_list()
    runwayLabels = match_to_runway(lat, lon)
    runwayName = get_runwayNanme(runwayLabels)

    if len(runwayName)==1:
        runway = runwayName[0]
        
        # get timestamp
        idx = runwayLabels.index(runway)
        timestamp = data_csign.loc[idx, 'timeH']
        # get firt point on runway
        coor = (data_csign.loc[idx, 'lat'], data_csign.loc[idx, 'lon'])
        # get runwayTHR
        runwayTHR = get_runwayTHR(coor, runway)
        if runwayTHR == 'other':
            print(f"check: {data_csign.loc[0, 'callsign']}")

        rtn = [runwayTHR, timestamp]
    else:
        rtn = ['', 0]

    return rtn


def get_runwayTHR_timestamp_cat21_allAC_byDate(date):
    file = dir_arrivalTraj + str(date) + ".csv"
    df = pd.read_csv(file)
    df = df.rename(columns={'alti': 'fl'})[['timeH', 'lat', 'lon', 'fl', 'callsign']]
    callsigns = df['callsign'].unique().tolist()
    print(f"num of callsigns: {len(callsigns)}")

    df_allAC = pd.DataFrame(columns=df.columns.to_list() + ['runwayTHR', 'runwayTHR_timestamp'])

    cnt = 0

    for csign in callsigns:
        df_csign = df[df['callsign'] == csign].reset_index(drop=True)
        lastRows = df_csign[df_csign['fl']<5].reset_index(drop=True)
        [runwayTHR, timestamp] = get_runwayTHR_timestamp_byAC(lastRows)
        if runwayTHR != 'other' and timestamp !=0: 
            df_csign['runwayTHR'] = runwayTHR
            df_csign['runwayTHR_timestamp'] = timestamp
            df_csign = df_csign[df_csign['timeH']<=timestamp].reset_index(drop=True)
            df_allAC = pd.concat([df_allAC, df_csign])
        elif timestamp == 0:
            cnt += 1
    print("---------------------------------------")
    print(date)
    print(f"total number of A/C with last point not on runway: {cnt}")
    print("---------------------------------------")

    df_allAC = df_allAC.reset_index(drop=True)
    file_save = dir_arrivalTraj_filter + str(date) + ".csv"
    df_allAC.to_csv(file_save)
        
    return df_allAC

