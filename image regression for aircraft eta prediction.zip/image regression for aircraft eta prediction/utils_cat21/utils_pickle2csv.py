import pickle as pkl
import pandas as pd
import numpy as np


from utils_cat21.utils_data_cat21 import *
import pandas as pd

'''
note: time zone: +8
'''

def pickle2csv_period(date_start: int, date_end: int)->None:
   
    for date in range(date_start, date_end+1):
        list_merge = []
        columns=['timeH', 'lat', 'lon', 'alti', 'callsign']
        file_csv = dir_csv +  str(date) + ".csv"
        for hour in range(0,24):
            file =  str(date) + "_" + str(hour) + "_" + str(hour+1) 
            file_pickle = dir_pickle + file + ".pickle"

            with open(file_pickle, "rb") as f:
                object = pkl.load(f)

            for key, value in object.items():
                list_merge += value

        df = pd.DataFrame(list_merge, columns=columns)
        df = df.dropna(subset=['callsign'])
        df.astype({'timeH': np.int64, 'lat': float, 'lon': float, 'lon': float, 'callsign': str}) 
        df_save = df.sort_values(['callsign', 'timeH']).reset_index(drop=True)
        df_save.to_csv(file_csv)
        print(date)

    return   
        




    
    

    
