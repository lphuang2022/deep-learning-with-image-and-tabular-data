from utils_cat21 import *
import pandas as pd
import os
import re

def save_etaPrediction(results, slot, sta):
    df_results = pd.DataFrame(results)
    file = dir_eta_prediction + "_slot_" + str(slot) + "_sta_" + str(sta) + ".csv"
    df_results.to_csv(file)
    print(f"prediction saved, slot {slot}, sta: {sta}")
    

def get_holding_callsignList(date):
        holdings = ["holding start", "holding end"]
        evt_file = dir_tmaEvent + str(date) + "allEvents.csv"
        df_event = pd.read_csv(evt_file, index_col=0)
        df_holdings = df_event[df_event['event'].isin(holdings)].reset_index(drop=True)
        return df_holdings['callsign'].unique().tolist()


def get_holdingLabels(df_eta, date):
    holdingCallsigns = get_holding_callsignList(date)
    df_eta['holding'] = 0
    df_eta.loc[df_eta['callsign'].isin(holdingCallsigns), 'holding'] = 1
    return df_eta

def remove_outliers(df_comb, col = "eta"):
    q_low = df_comb[col].quantile(0.1)
    q_hi = df_comb[col].quantile(0.9)
    df_comb = df_comb[(df_comb[col] < q_hi) & (df_comb[col] > q_low)].reset_index(drop=True)
    avg = df_comb[col].mean()
    std = df_comb[col].std()
    # df_comb = df_comb[(df_comb[col] > avg - 3*std) & (df_comb[col] < avg + 3*std)].reset_index(drop=True)
    df_comb = df_comb[(df_comb[col] < avg + 3*std)].reset_index(drop=True)
    return df_comb


def feature_scalor(df_comb):
    for col in df_comb.columns.tolist()[:-3]:
          df_comb[col] = df_comb[col]/max(df_comb[col].max(), 1)
    return df_comb

def feature_normalize(df_comb):
    skip = ['image', 'eta', 'callsign', 'holding']
    cols = list(set(df_comb.columns.tolist())-set(skip))
    for col in cols:       
          avg = df_comb[col].mean()
          std = df_comb[col].std()
          if std == 0:
               std = 1
          df_comb[col] = (df_comb[col]-avg)/std
    return df_comb

def get_gapTBC(df):
    df.sort_values(by = ['timestamp_tbc'], inplace=True, ascending=False)
    df.reset_index(drop=True)
    df['gapTBC'] = 0
    df['gapTBC'] = df['timestamp_tbc'] - df['timestamp_tbc'].shift(-1)
    df = df.iloc[:-1].reset_index(drop=True)
    return df
          

def csvETA_combine(dates, prefix):
    cols = [
            'recat_label', 'is_weekday', 'is_peakhour', 
            'drct', 'sknt', 'gust', 'vsby', 'skyc1', 'skyl1', 
            'runwayChange', 'numARR_on_02L20R', 'numARR_on_02R20L', 'arr_runway',
            'image','holding', 'eta', 'callsign', 'gapTBC'
            ]
    dtypes = {'recat_label': 'float64',
             'is_weekday': 'float64', 
             'is_peakhour': 'float64', 
            'drct': 'float64', 'sknt': 'float64', 'gust': 'float64', 'vsby': 'float64', 'skyc1': 'float64', 'skyl1': 'float64', 
            'runwayChange': 'float64', 'numARR_on_02L20R': 'float64', 'numARR_on_02R20L': 'float64', 
            'image': 'str','holding': 'float64', 'eta': 'float64'}
    
    slots = [30, 60, 90]
    stas = [10, 15, 20, 25, 30]
    # df_comb = pd.DataFrame(columns=cols)
    for slot in slots:
        for sta in stas:
            df_comb = pd.DataFrame(columns=cols)
            for date in dates:
                file = dir_csvETA + str(date) + "_slot_" + str(slot) + "_sta_" + str(sta) + ".csv"
                df = pd.read_csv(file, index_col=0)
                df['arr_runway'] = df['numARR_on_02L20R'] + df['numARR_on_02R20L']
                df = get_gapTBC(df)
                df = get_holdingLabels(df, date)[cols]# add holding col
                df_comb = pd.concat([df_comb, df])   
            dir_save = dir_csvETA_datesCombine + prefix +  "/" 
            if not os.path.exists(dir_save):
                os.mkdir(dir_save)
            file_save = dir_save + "slot_" + str(slot) + "_sta_" + str(sta) + ".csv"
            # df_comb['arr_runway'] = df_comb["numARR_on_02L20R"] + df_comb['numARR_on_02R20L']
            df_comb['image'] = df_comb['image'].str.replace("C:/_Huang", "D:")
            df_comb.loc[df_comb['drct']=='M', 'drct'] = 0
            df_comb.loc[df_comb['gust']=='M', 'gust'] = 0
            df_comb['drct'] = df_comb['drct'].replace('0', 0).astype(int)
            df_comb['gust'] = df_comb['gust'].replace('0', 0).astype(int)
            df_comb = remove_outliers(df_comb, col = "eta")
            # df_comb = feature_scalor(df_comb)
            df_comb = feature_normalize(df_comb)
            df_comb['date'] = date
            df_comb['ac'] = df_comb['callsign'].map(lambda x: re.sub("[a-zA-Z]", "", x))
            # df_comb["ac"] = df_comb["callsign"].str.replace("[a-zA-Z]", "", regex=True)
            df_comb['ac'] = pd.to_numeric(df_comb['ac'], errors='coerce')
            df_comb['ac'] = df_comb['ac'].fillna(0)
            df_comb = df_comb.reset_index(drop=True)
            df_comb['ind'] = pd.Series(range(len(df_comb)))

            df_comb.to_csv(file_save)
    print("csv file comb finsihed.")
    return