from utils_cat21 import *
import numpy as np
import pandas as pd
from scipy import interpolate as interpolate
import mpu
from datetime import datetime
import pytz
import matplotlib.pyplot as plt
import os
'''
verstion: 2022-08-29
contributor: huanglp
target: predict aircraft landing time


terminology

- TBC: TMA boundary circle with 50 NM to the airport
- TBX: TMA boundary circle extended with 60 NM to the airport

- TI: trajectory image
- TIS30, TIS60, TIS90: trajectory image in 30 seconds, 60 seconds, and 90 seconds
- SLS: slot size for generating the trajectory image, 
        which is based on the analysis of one-round holding duration and the time consumption between, 
        in this study, it is 1, 2 minutes
- ETA: expected time of arrival
- T_tbc: timestamp when flight hits the TBC
- T_tbx: timestamp when fligth hits the TBX
- T_initETA = T_tbc - SLS 
- T_thr: timestamp when flight arrives at the runway threshold
- t_landing := T_thr - T_initETA, i.e., the flight landing time consumption from the TMA extended boundary, which is the ground truth label


parameters:
- SLS: 60s, 90s

'''
# todo:
# 1. eta lable: get T_bc, get t_landing with SLS as parameters----coding finished
# 2. generate trajectory image: two datasets, SLS = 60, 90 sec, get T_initETA, and T_itnitETA + SLS, get two datasets for M1TI and M2TI based on two timestamps
# 3. holding pretraining using 1025-2031 one week data, input: trajectory images, label: holding duration 《--- semi-suppervised learning
# 4. eta modeling: inputs of holding learning network + output of holding network

'''
inputs for the modeling:
as shown in the summary Table
- MTI
- Runway Usage: num_dep, num_arr on both runwayTHRs in the capture slot
- Runway Direction Change Label in the capture slot
- external
'''

def dist2Airport(coor):
    return mpu.haversine_distance(coor, airport_coor)*1000

def get_timestamp_hitBoundary(df_csign, radius):# radius in NM
    distTHR = radius*1852
    epsilon = 500
    for _, row in df_csign.iterrows():
        coor = (row['lat'], row['lon'])
        dist = dist2Airport(coor)
        if abs(dist - distTHR) < epsilon:
            return row['timeH']
    return 0
    
def get_tbc_tbx_timestamp_cat21_allAC_byDate(date):

    file = dir_arrivalTraj_filter + str(date) + ".csv"
    df = pd.read_csv(file, index_col=0)
    print(f"original A/C: {len(df['callsign'].unique())}")
    df = df[(df['lat']>= tbx_spaceRange['lat_min']) & (df['lat'] <= tbx_spaceRange['lat_max'])]
    df = df[(df['lon'] >= tbx_spaceRange['lon_min']) & df['lon'] <= tbx_spaceRange['lon_max']].reset_index(drop=True)
    
    data_eta = []
    cnt = 0
    
    radius_tbx = 60 # NM
    radius_tbc = 50 
    callsigns = df['callsign'].unique().tolist()
    for csign in callsigns:
        df_csign = df[df['callsign'] == csign].reset_index(drop=True)
        if len(df_csign)<120:
            cnt += 1
            continue
        timestamp_tbx = get_timestamp_hitBoundary(df_csign, radius_tbx)
        if timestamp_tbx == 0:
            continue

        df_csign = df_csign[(df_csign['lat']>= tbc_spaceRange['lat_min']) & (df_csign['lat'] <= tbc_spaceRange['lat_max'])]
        df_csign= df_csign[(df_csign['lon'] >= tbc_spaceRange['lon_min']) & df_csign['lon'] <= tbc_spaceRange['lon_max']].reset_index(drop=True)
        timestamp_tbc = get_timestamp_hitBoundary(df_csign, radius_tbc)
        if timestamp_tbc == 0:
            continue
        timeGap_tbx_tbc = timestamp_tbc - timestamp_tbx
        if timeGap_tbx_tbc < 0:
            continue

        runway = df_csign.loc[0, 'runwayTHR']
        timestamp_runwayTHR = df_csign.loc[0, 'runwayTHR_timestamp']
        eta = timestamp_runwayTHR - timestamp_tbc
        data_eta.append([csign, runway, timestamp_runwayTHR, timestamp_tbc, timestamp_tbx, timeGap_tbx_tbc, eta])

    df_eta = pd.DataFrame(data_eta, columns=['callsign', 'runway', 'timestamp_runway', 'timestamp_tbc', 'timestamp_tbx', 'timeGap_tbx_tbc', 'eta'])
    file_save = dir_csv_etaLabel + str(date) + ".csv"
    df_eta.to_csv(file_save)

    print(f"eta lable finished, No. of AC : {len(df_eta['callsign'].unique())}, cnt: {cnt}")

    return df_eta

# ----------------   feature engineering functions for eta modeling ----------------------------------------

def get_weatherFeature(df_eta):
    df_eta['drct'] = 0
    df_eta['sknt'] = 0
    df_eta['gust'] = 0
    df_eta['vsby'] = 0
    df_eta['skyc1'] = 0
    df_eta['skyl1'] = 0

    df_metar = pd.read_csv(file_metar)[['valid', 'drct', 'sknt', 'gust','vsby', 'skyc1', 'skyl1']]
    df_metar['timestamp'] = df_metar['valid'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d %H:%M').replace(tzinfo=pytz.UTC).timestamp())

    for i in range(len(df_eta)):
        time = df_eta.loc[i, 'timestamp_tbc']
        df_metar_temp = df_metar[df_metar['timestamp']<=time].reset_index(drop=True)
        df_metar_temp = df_metar_temp.sort_values(by = 'timestamp', ascending=False)
        if len(df_metar_temp)>0:
            df_eta.loc[i, 'drct'] = df_metar_temp.loc[0, 'drct']
            df_eta.loc[i, 'sknt'] = df_metar_temp.loc[0, 'sknt']
            df_eta.loc[i, 'gust'] = df_metar_temp.loc[0, 'gust']
            df_eta.loc[i, 'vsby'] = df_metar_temp.loc[0, 'vsby']
            df_eta.loc[i, 'skyc1'] = 0 if df_metar_temp.loc[0, 'skyc1'] == 'FEW' else 1
            df_eta.loc[i, 'skyl1'] = df_metar_temp.loc[0, 'skyl1']

    return df_eta


def get_seasonality(df_eta):
    weekends = [5, 6]
    dict_seansonality = {'peak_hour': [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                         'non_peak': [0, 1, 2, 3]}
    df_eta['is_weekday'] = 1
    df_eta['is_peakhour'] = 'peak_hour'
    dict_peak = {'peak_hour': 1,
                 'non_peak': 0}

    for i in range(len(df_eta)):
        time = df_eta.loc[i, 'timestamp_tbc']
        if datetime.fromtimestamp(time).weekday() in weekends:
            df_eta.loc[i, 'is_weekday'] = 0 # get weekday feature
        hour = datetime.fromtimestamp(time).hour
        for k, v in dict_seansonality.items():
            if hour in v:
                df_eta.loc[i, 'is_peakhour'] = dict_peak[k]

    return df_eta

def get_recat(df_eta):
    df_FPL = pd.read_csv(file_FPL, index_col=0)
    df_FPL = df_FPL[df_FPL['ADES']=='WSSS'].reset_index(drop=True)
    df_recat = pd.read_csv(file_recat)
    df_recat = df_recat.dropna(subset=['type_cat']).reset_index(drop=True)
    
    df_eta['recat'] = 'Upper Medium'
    df_eta['recat_label'] = 2
    
    dict_model_recat = dict(zip(df_recat['model_type'], df_recat['type_cat']))
    for i in range(len(df_eta)):
        csign = df_eta.loc[i, 'callsign']
        csign_runwayTime = df_eta.loc[i, 'timestamp_runway']
        df_FPL_csign = df_FPL[df_FPL['Callsign']==csign].reset_index(drop=True)
        if len(df_FPL_csign)>0:
            format="%d/%m/%Y %H:%M"
            # df_FPL_csign['timestamp_ATA'] = pd.to_datetime(df_FPL_csign['ATA'], unit='s')
            df_FPL_csign['timestamp_ATA'] = df_FPL_csign['ATA'].apply(lambda x: datetime.strptime(x, format).replace(tzinfo=pytz.UTC).timestamp())
            df_FPL_csign['gap'] = abs(df_FPL_csign['timestamp_ATA'] - csign_runwayTime)
            df_FPL_csign = df_FPL_csign.sort_values('gap').reset_index(drop=True)

            model = df_FPL_csign.loc[0, 'Aircraft Type']
            if model in dict_model_recat.keys():
                recat = dict_model_recat[model]
                df_eta.loc[i, 'recat'] = recat
                df_eta.loc[i, 'recat_label'] = dict_recat_label[recat]
    print(f"get recat finished.")
    return df_eta

def label_year_month_hour_hourMinite_byCol(df, byCol):
    # df['month'] = df[byCol].apply(lambda x: datetime.fromtimestamp(x).month)
    df['day'] = df[byCol].apply( lambda x: datetime.fromtimestamp(x).day)
    df['hour'] = df[byCol].apply( lambda x: datetime.fromtimestamp(x).hour)
    df['day_hour'] = df['day']*100 + df['hour']
    # df['hour_minute'] = df[byCol].apply( lambda x: datetime.fromtimestamp(x).strftime('%H:%M'))
    # df['minute'] = df[byCol].apply( lambda x: datetime.fromtimestamp(x).strftime('%M'))

    return df


def generate_feature_runwayOperation(df_eta, slot_size=60, sta = 15): #sta in minutes
    # 1. runway threhold change label in the time slot, from df_eta
    # 2. runway usage, num of arrivals, from df_eta.
    df_eta['runwayChange'] = 0
    df_eta['numARR_on_02L20R'] = 0
    df_eta['numARR_on_02R20L'] = 0

    runway1 = {
                '02L': '02L20R',
                '20R': '02L20R'
                }
    runway3 =  {
                '02R': '02R20L',
                '20L': '02R20L'
                }
    
    for i in range(len(df_eta)):
        time = df_eta.loc[i, 'timestamp_tbc']
        temp = df_eta[(df_eta['timestamp_tbc']>=time-sta*60) & (df_eta['timestamp_tbc']<=time)].reset_index(drop=True)
        tempArr= temp[temp['runway'].isin(list(runway1.keys()))]
        df_eta.loc[i, 'numARR_on_02L20R'] = len(tempArr)
        if len(tempArr['runway'].unique())>1:
            df_eta.loc[i, 'runwayChange'] = 1

        tempArr= temp[temp['runway'].isin(list(runway3.keys()))]
        df_eta.loc[i, 'numARR_on_02R20L'] = len(tempArr)
        if len(tempArr['runway'].unique())>1:
            df_eta.loc[i, 'runwayChange'] = 1
    
    # # --------------statistic callculation cat62, not tested----------------------
    # file_runway = dir_data_rtt_rot_save + str(date) + ".csv"
    # df_runway = pd.read_csv(file_runway, index_col=0)
    # df_runway['timeH_onRunway'] = df_runway['timeH_onRunway'] - timestamp_shift
    # df_runway = label_year_month_hour_hourMinite_byCol(df_runway, 'timeH_onRunway')
    # df_runway = df_runway[df_runway['hour']>=8].reset_index(drop=True)
    # df_runway = df_runway.reset_index(drop=True)

    # if date not in [221025, 221101]:
    #     # previous day
    #     file_runway = dir_data_rtt_rot_save + str(date-1) + ".csv"
    #     df_runway_pre = pd.read_csv(file_runway, index_col=0)
    #     df_runway_pre['timeH_onRunway'] = df_runway_pre['timeH_onRunway'] - timestamp_shift
    #     df_runway_pre = label_year_month_hour_hourMinite_byCol(df_runway_pre, 'timeH_onRunway')
    #     df_runway_pre = df_runway_pre[df_runway_pre['hour']<8].reset_index(drop=True)

    #     df_runway = pd.concat([df_runway, df_runway_pre])
    #     df_runway = df_runway.sort_values('timeH_onRunway').reset_index(drop=True)
    
    return df_eta
    
def generate_trajImage_byDateSlot(date, df_eta, slot_size = 60, sta=15):#slot size in seconds
    # based on timestamp_tbc, slot_size, generate image from cat21 within time window [timestamp_tbc-slot_size, timstamp_tbc]
    file = dir_arrivalTraj_filter + str(date) + ".csv"
    df = pd.read_csv(file, index_col=0)
    s_point = 2
    s_head = 10

    df_eta['image'] = ""

    for i in range(len(df_eta)):
        csign = df_eta.loc[i, 'callsign']
        df_eta_csign = df_eta[df_eta['callsign']==csign].reset_index(drop=True)
        timestamp_tbc = df_eta_csign.loc[0, 'timestamp_tbc']

        df_slot = df[(df['timeH']>= timestamp_tbc-slot_size) & (df['timeH'] <= timestamp_tbc)]
        df_target = df_slot[df_slot['callsign'] == csign].reset_index(drop=True)
        df_background = df_slot[df_slot['callsign'] != csign].reset_index(drop=True)
        
        cor_target = df_target[['lon', 'lat', 'fl', 'callsign']]

        # generate image
        fig = plt.figure(figsize=(8, 8), dpi=64)
        ax = plt.gca()
        ax.set_xlim(103-0.1,105+0.1)
        ax.set_ylim(0.25,2.45)

        plt.axis('off')
        ax.scatter(cor_target.iloc[:,0],cor_target.iloc[:,1], c = "r", s =s_point, marker=".", zorder = 2)
        ax.scatter(cor_target.iloc[-1,0],cor_target.iloc[-1,1], c = "r", s =s_head, marker=".", zorder = 2)

        if len(df_background['callsign'].unique())>0:
            cor_background = df_background[['lon', 'lat', 'fl', 'callsign']]
            head_background = pd.DataFrame(columns=['lon', 'lat'])
            grouped = cor_background.groupby('callsign')
            for _, group in grouped:
                temp_bkg = pd.DataFrame([[group.iloc[-1,0], group.iloc[-1, 1]]], columns=['lon', 'lat'])
                head_background = pd.concat([temp_bkg, head_background])
            
            ax.scatter(cor_background.iloc[:,0],cor_background.iloc[:,1], c = "b", s =s_point, marker=".", zorder = 1)
            ax.scatter(head_background.iloc[:,0],head_background.iloc[:,1], c = "b", s =s_head, marker=".", zorder = 1)

            del cor_background
            del head_background
            del grouped  

        # save image
        dir_trajImage = dir_trajImage_1 if date < 221101 else dir_trajImage_2
        anot = "slot_"+ str(slot_size) + "_sta_" + str(sta) + "/"
        dir = dir_trajImage + anot

        if not os.path.exists(dir):
            os.mkdir(dir)
        file_image = dir + str(date) + "_"+ csign + '.png'
        plt.savefig(file_image, bbox_inches ='tight', pad_inches=0)

        plt.clf()
        plt.close()
        del fig
        del df_eta_csign
        del df_slot
        del df_target
        del df_background
        del cor_target
        df_eta.loc[i, 'image'] = file_image
        
    return df_eta

def get_otherFeatures(df_eta, slot_size=60, sta = 15):
    df_eta = get_recat(df_eta)
    df_eta = get_seasonality(df_eta)
    df_eta = get_weatherFeature(df_eta)
    df_eta = generate_feature_runwayOperation(df_eta, slot_size, sta)
    return df_eta


def eta_featureEng(date, slot_size=60, sta = 15):
    file = dir_csv_etaLabel + str(date) + ".csv"
    df_eta = pd.read_csv(file, index_col=0)
    df_eta = get_otherFeatures(df_eta, slot_size, sta)
    df_eta = generate_trajImage_byDateSlot(date, df_eta, slot_size, sta)
    anot = "_slot_"+ str(slot_size) + "_sta_" + str(sta)
    file = dir_csvETA + str(date) + anot + ".csv"
    df_eta.to_csv(file)

    print(f"feature eng finished for {date}")
    return df_eta












