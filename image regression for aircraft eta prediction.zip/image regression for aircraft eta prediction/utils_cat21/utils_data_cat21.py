import shapefile
from shapely.geometry import Point, shape

timestamp_shift = 2082844800

# FPL
file_FPL = "C:/_Huang/data22Analyze/analyze_CAT62/utils_CAT62/csv_data/Flight_Plan_20220901_20221130.csv"
file_recat = "C:/_Huang/ROEandRSE/1_data/aircrafttype_category.csv"
file_metar = "C:/_Huang/data22Analyze/metar/WSSS22.csv"

# dir for pickle and csv
dir_pickle = data22_cat21_pickle = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/raw_data_tma_2022/"
dir_csv = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/csv_cat21/"
dir_data_rtt_rot_save = "C:/_Huang/data22Analyze/analyze_CAT62/data_rtt_rot/"

# dir for saving data, holding detection, and traj replay
dir_datasplit = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/csv_cat21_split_bycallsign/"
# dir_arrivalTraj = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/csv_arrival_traj/"
dir_arrivalTraj = dir_csv 
dir_arrivalTraj_filter = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/csv_arrival_traj_filter/"


# coors for runwayTHRs
runwayTHRs = {
            '02L': (1 + 20/60 + 56.27/3600, 103 + 58/60 + 38.82/3600), 
            '20R': (1 + 22/60 + 33.95/3600, 103 + 59/60 + 20.06/3600),
            '02C': (1 + 19/60 + 43.51/3600, 103 + 59/60 + 5.86/3600),
            '20C': (1 + 21/60 + 43.37/3600, 103 + 59/60 + 56.46/360),
            '02R': (1 + 19/60 + 20.59/3600, 103 + 59/60 + 59.45/3600),
            '20L': (1 + 21/60 + 20.45/3600, 104 + 50.05/3600)
             }

airport_coor = (1.3592, 103.9893)

# # shapefiles
# dir_runway_shapefile = "C:/_Huang/data22Analyze/analyze_CAT62/utils_CAT62/Shapefiles/runway_forArr/"
# dir_aerodrome_shapefile = "C:/_Huang/data22Analyze/analyze_CAT62/utils_CAT62/Shapefiles/aerodrome/"
# shp1 = shapefile.Reader(dir_runway_shapefile + 'rwyBox02L.shp') #open the shapefile
# shp2 = shapefile.Reader(dir_runway_shapefile + 'rwyBox02C.shp') #open the shapefile
# shp3 = shapefile.Reader(dir_runway_shapefile + 'rwyBox02R.shp') #open the shapefile
# shp_Aerodrome = shapefile.Reader(dir_aerodrome_shapefile + 'Aerodrome.shp')

# shp1_data = shp1.shapes() # get all the polygons
# shp2_data = shp2.shapes() # get all the polygons
# shp3_data = shp3.shapes() # get all the polygons
# shp_Aerodrome_data = shp_Aerodrome.shapes()

runways = ['02L20R', '02C20C', '02R20L']
airport_labels = runways + ['aerodrome']


# data for eta data preparing
rel = 0.000001
tbc_spaceRange = {'lat_min': round(airport_coor[0] - 50/59.9, 6) - rel,
                  'lat_max': round(airport_coor[0] + 50/59.9, 6) + rel,
                  'lon_min': round(airport_coor[1] - 50/59.9, 6) - rel,
                  'lon_max': round(airport_coor[1] + 50/59.9, 6) + rel,
                  }

tbx_spaceRange = {'lat_min': round(airport_coor[0] - 60/59.9, 6) - rel,
                  'lat_max': round(airport_coor[0] + 60/59.9, 6) + rel,
                  'lon_min': round(airport_coor[1] - 60/59.9, 6) - rel,
                  'lon_max': round(airport_coor[1] + 60/59.9, 6) + rel,
                  }
dir_csv_etaLabel = "C:/_Huang/data22Analyze/analyze_CAT21/data_CAT21/csv_etaLabel/"
# batamn event, not used

dict_recat_label = {
                    'Light': 0,
                    'Lower Medium': 1,
                    'Upper Medium': 2,
                    'Lower Heavy': 3,
                    'Upper Heavy': 4,
                    'Super Heavy': 5
                    }
# ---------------------------------------   above used for data preparing   --------------------------------------

# --------------------------------------     below used for model train and test    ------------------------------
dir_tmaEvent = "D:/data22Analyze/1_itsc_paperRevise/data_holdingEvents/"
dir_trajImage_1 = "D:/data22Analyze/1_itsc_paperRevise/trajectory_image/2210/"
dir_trajImage_2 = "D:/data22Analyze/1_itsc_paperRevise/trajectory_image/2211/"
dir_csvETA = "D:/data22Analyze/1_itsc_paperRevise/csv_eta/"
dir_csvETA_datesCombine = "D:/data22Analyze/1_itsc_paperRevise/csv_eta_datesCombine/"
dir_csvETA_datesCombine_v2 = "D:/data22Analyze/1_itsc_paperRevise/csv_eta_datesCombine_v2NewFeatures/"
dir_eta_prediction = "D:/data22Analyze/1_itsc_paperRevise/eta_prediction/"
dir_eta_pred_nohold = "D:/data22Analyze/1_itsc_paperRevise/eta_prediction/eta_ret_noholdModel/"
dir_hld_ret = "D:/data22Analyze/1_itsc_paperRevise/eta_prediction/holding_ret/"

dir_eta_pred_withHold = "D:/data22Analyze/1_itsc_paperRevise/eta_prediction/eta_ret_withHolding/"